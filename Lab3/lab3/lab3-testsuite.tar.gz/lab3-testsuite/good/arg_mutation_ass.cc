void cdec(int c) {
  c--;
}

int main () {
  int c;
  cdec(c = 0);
  printInt(c);

  return 0;
}
