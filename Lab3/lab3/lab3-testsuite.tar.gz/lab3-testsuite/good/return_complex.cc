bool foo(int x) {
    if (x == 0) {
        return false;
    } else {}

    bool b = true;

    printInt(x);

    return b;
}

void printBool(bool b) {
    if (false) {}
    else

    if (b) {
          printInt(0);
    } else {
          printInt(1);
    }

}

int main() {
  printBool(foo(42));
  printBool(foo(0));
  return 0;
  printBool(true);
}
