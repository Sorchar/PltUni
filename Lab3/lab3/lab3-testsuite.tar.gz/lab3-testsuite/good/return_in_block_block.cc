int niam() {
  {{{{{
    {{{{{
      return 99;
    }}}}}
    printInt(2);
  }}}}}
  printInt(1);
}

int main() {
  {{{{{
    {{{{{
      printInt(niam());
      return 0;
    }}}}}
    printInt(3);
  }}}}}
  printInt(4);
}
