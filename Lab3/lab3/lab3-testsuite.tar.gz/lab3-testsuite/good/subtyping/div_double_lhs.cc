int main() {
  printDouble(1.0 / 2);
  return 0;
}
