int main () {
	if (3 <= 5.0)
		int y;
	else {}
	return 0;
}
