int main () {
	if (5 > 3.0)
		int y;
	else {}
	return 0;
}
