/* void expression as statement */

void foo() {
  printInt(1);
}

int main() {
  foo();
  return 0 ;

}
