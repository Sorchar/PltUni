int x(bool x) { return 0; }

int main() {
  int x = 5;
  return x;
}
