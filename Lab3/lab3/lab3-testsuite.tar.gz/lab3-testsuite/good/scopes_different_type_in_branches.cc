int main() {
	if (1 > 0) {
		int x = 0;	
	} else {
		bool x = true;
	}

	return 0;
}
