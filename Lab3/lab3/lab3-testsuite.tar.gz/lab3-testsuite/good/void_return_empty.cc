void empty() {}

int main() {
  return 0;
}
