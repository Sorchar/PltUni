int main() {
  double j = 22.5;
  double k = 23.5;
  j--;
  printDouble(j);
  printDouble(k--);
  return 0;
}
