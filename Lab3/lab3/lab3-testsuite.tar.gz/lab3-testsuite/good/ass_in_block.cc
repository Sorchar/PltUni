int main() {
        int x = 5;
        { x = 7; }
        printInt(x);
        return 0;
}
