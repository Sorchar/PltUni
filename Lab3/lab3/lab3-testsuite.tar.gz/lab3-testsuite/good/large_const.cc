int main() {
  printInt(1000);
  return 0;
}
