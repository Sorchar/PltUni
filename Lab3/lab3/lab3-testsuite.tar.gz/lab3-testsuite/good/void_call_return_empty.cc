void empty() {}

int main() {
  empty();
  return 0;
}
