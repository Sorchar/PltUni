f x = x + x;

main = print (if f then 1 else 0); -- operator if not defined for functions
