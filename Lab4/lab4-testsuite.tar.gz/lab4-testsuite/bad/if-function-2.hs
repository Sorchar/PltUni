K1 ignore = 1;

main = print (if K1 then 1 else 0);
