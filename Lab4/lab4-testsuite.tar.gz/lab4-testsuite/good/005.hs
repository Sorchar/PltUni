first x y = x - 1 ;
test = first 1 test ;
main = print test ; -- result 0 with -n, loops with -v
