main = print (0 < 0) ;  -- result 0
