one x = 2 ;

main = print ((\one -> one) 1) ;
